import "react-native-gesture-handler"; // IMPORTANTE: sempre no topo
import React, { useState } from "react";
// 1. Importe o componente Button
import { View, Text, StyleSheet, Button } from "react-native";
import { TapGestureHandler } from "react-native-gesture-handler";

export default function App() {
  const [count, setCount] = useState(0);

  const onSingleTap = () => {
    // É uma boa prática usar uma função de callback quando o novo estado depende do anterior
    setCount((currentCount) => currentCount + 1);
  };

  // 2. Crie uma função para resetar a contagem
  const onReset = () => {
    setCount(0);
  };

  return (
    <TapGestureHandler onActivated={onSingleTap}>
      <View style={styles.container}>
        <Text style={styles.text}>Toque na tela</Text>
        <Text style={styles.text}>Contagem de toques: {count}</Text>

        {/* 3. Adicione o botão e um container para ele */}
        <View style={styles.buttonContainer}>
          <Button
            title="Resetar Contagem"
            onPress={onReset}
            color="#948e8b" // Uma cor para destacar o botão
          />
        </View>
      </View>
    </TapGestureHandler>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f2f2f2",
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    fontSize: 20,
    margin: 10,
  },
  // 4. Estilo para o container do botão (para dar um espaçamento)
  buttonContainer: {
    marginTop: 20, //define a largura
    width: "20%", // Define uma largura para o botão
    borderRadius: 4,
  },
});
