import React from "react";
import { View, Text, StyleSheet } from "react-native";

// Componente Header simples
export default function Header() {
  return (
    <View style={styles.header}>
      <Text style={styles.headerText}>Meu App</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    width: "100%",
    height: 60,
    backgroundColor: "black",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    color: "white",
  },
});
