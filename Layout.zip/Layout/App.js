import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, ScrollView } from "react-native";
import Header from "./src/components/Header";
import Footer from "./src/components/Footer";
import Main from "./src/components/Main";
import Menu from "./src/components/Menu";
import ConfigScreen from "./screens/ConfigScreen";
import HomeScreen from "./screens/HomeScreen";
import PerfilScreen from "./screens/PerfilScreen";
import TapGestureHandler from "./screens/TapGestureHandler";
import RotationGestureHandler from "./screens/RotationGestureHandler";
import PinchGestureHandler from "./screens/PinchGestureHandler";
import LongPressGestureHandler from "./screens/LongPressGestureHandler";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import Acelerometro from "./screens/Acelerometro";
import Som from "./screens/Som";
import Mapa from "./screens/Mapa";
import Camera from "./screens/Camera";
import PersistenciaScreen from "./screens/PersistenciaScreen";
import Wifi from "./screens/Wifi";

const Drawer = createDrawerNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen
          name="HomeScreen"
          component={HomeScreen}
          options={{ title: "Home" }}
        />
        <Drawer.Screen
          name="ConfigScreen"
          component={ConfigScreen}
          options={{ title: "Configurações" }}
        />
        <Drawer.Screen
          name="PerfilScreen"
          component={PerfilScreen}
          options={{ title: "Perfil" }}
        />
        <Drawer.Screen
          name="TapGestureHandler"
          component={TapGestureHandler}
          options={{ title: "Contador" }}
        />
        <Drawer.Screen
          name="RotRotationGestureHandleração"
          component={RotationGestureHandler}
          options={{ title: "Rotação" }}
        />
        <Drawer.Screen
          name="ZoPinchGestureHandlerom"
          component={PinchGestureHandler}
          options={{ title: "Zoom" }}
        />
        <Drawer.Screen
          name="LongPressGestureHandler"
          component={LongPressGestureHandler}
          options={{ title: "Pressionar" }}
        />
        <Drawer.Screen
          name="Acelerometro"
          component={Acelerometro}
          options={{ title: "Acelerometro" }}
        />
        <Drawer.Screen
          name="Mapa"
          component={Mapa}
          options={{ title: "Mapa" }}
        />
        <Drawer.Screen name="Som" component={Som} options={{ title: "Som" }} />
        <Drawer.Screen
          name="Camera"
          component={Camera}
          options={{ title: "Camera" }}
        />

          <Drawer.Screen
          name="PersistenciaScreen"
          component={PersistenciaScreen}
          options={{ title: "LocalStorage" }}
        />

         <Drawer.Screen
          name="Wifi"
          component={Wifi}
          options={{ title: "Wifi" }}
        />
      </Drawer.Navigator>
      
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
