// ...existing code...
import { StatusBar } from "expo-status-bar";
import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  Dimensions,
} from "react-native";
import { Audio } from "expo-av";
import React, { useEffect, useState } from "react";

export default function Som() {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLooping, setIsLooping] = useState(false);

  const windowWidth = Dimensions.get("window").width;
  const imageSize = Math.min(300, Math.floor(windowWidth * 0.6)); // square size responsive

  async function playSound() {
    try {
      if (!sound) {
        const { sound: newSound } = await Audio.Sound.createAsync(
          // áudio dentro da pasta assets
          require("../assets/kiryuu - Is it all my fault_(MP3_128K).mp3"),
          { isLooping }
        );
        setSound(newSound);
        await newSound.playAsync();
        setIsPlaying(true);
      } else if (!isPlaying) {
        await sound.playAsync();
        setIsPlaying(true);
      }
    } catch (e) {
      console.warn("playSound error:", e);
    }
  }

  async function pauseSound() {
    if (sound) {
      await sound.pauseAsync();
      setIsPlaying(false);
    }
  }

  async function toggleLoop() {
    if (sound) {
      await sound.setIsLoopingAsync(!isLooping);
    }
    setIsLooping((prev) => !prev);
  }

  async function restartSound() {
    if (sound) {
      await sound.stopAsync();
      await sound.setPositionAsync(0);
      await sound.playAsync();
      setIsPlaying(true);
    }
  }

  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]);

  return (
    <View style={styles.container}>
      {/* Imagem quadrada */}
      <Image
        source={require("../assets/kiryuu.webp")}
        style={[styles.imageSquare, { width: imageSize, height: imageSize }]}
        resizeMode="cover"
      />

      <Text style={styles.title}>Reprodutor de Áudio</Text>

      <View style={{ width: "60%", marginBottom: 8 }}>
        <Button
          title={isPlaying ? "Pausar" : "Tocar"}
          onPress={isPlaying ? pauseSound : playSound}
        />
      </View>
      <View style={{ width: "60%", marginBottom: 8 }}>
        <Button
          title={isLooping ? "Repetir: Ligado" : "Repetir: Desligado"}
          onPress={toggleLoop}
          color={isLooping ? "#4caf50" : "#757575"}
        />
      </View>
      <View style={{ width: "60%", marginBottom: 8 }}>
        <Button title="Repetir Agora" onPress={restartSound} color="#2196f3" />
      </View>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    padding: 16,
  },
  imageSquare: {
    borderRadius: 8,
    marginBottom: 16,
    backgroundColor: "#ddd",
  },
  title: {
    fontSize: 24,
    marginBottom: 12,
  },
});
