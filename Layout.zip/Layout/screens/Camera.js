import React, { useState, useEffect } from "react";
import { View, Button, Text, StyleSheet, Alert } from "react-native";
import { Camera } from "expo-camera";
import * as MediaLibrary from "expo-media-library"; // Para salvar a foto

export default function CameraComponent() {
  const [hasPermission, setHasPermission] = useState(null); // Estado para verificar a permissão
  const [type, setType] = useState(Camera.Constants.Type.back); // Tipo da câmera (frontal ou traseira)
  const [cameraRef, setCameraRef] = useState(null); // Referência da câmera

  useEffect(() => {
    (async () => {
      // Solicita permissão para câmera e mídia
      const { status: cameraStatus } = await Camera.requestCameraPermissionsAsync();
      const { status: mediaStatus } = await MediaLibrary.requestPermissionsAsync(); // Permissão para salvar fotos
      setHasPermission(cameraStatus === "granted" && mediaStatus === "granted"); // Verifica ambas permissões
    })();
  }, []);

  const takePicture = async () => {
    if (cameraRef) {
      const photo = await cameraRef.takePictureAsync();
      console.log(photo); // Mostra informações da foto no console
      try {
        const asset = await MediaLibrary.createAssetAsync(photo.uri); // Cria o ativo na galeria
        MediaLibrary.createAlbumAsync("Fotos do App", asset, false); // Cria ou adiciona à pasta
        Alert.alert("Foto salva", "Sua foto foi salva na galeria.");
      } catch (error) {
        Alert.alert("Erro", "Não foi possível salvar a foto.");
      }
    }
  };

  if (hasPermission === null) {
    return <Text>Solicitando permissão...</Text>;
  }

  if (hasPermission === false) {
    return <Text>Sem permissão para acessar a câmera.</Text>;
  }

  return (
    <View style={styles.container}>
      <Camera
        style={styles.camera}
        type={type}
        ref={(ref) => setCameraRef(ref)}
      >
        <View style={styles.buttonContainer}>
          <Button
            title="Trocar Câmera"
            onPress={() => {
              setType(
                type === Camera.Constants.Type.back
                  ? Camera.Constants.Type.front
                  : Camera.Constants.Type.back
              );
            }}
          />
          <Button
            title="Tirar Foto"
            onPress={takePicture} // Função para tirar a foto
          />
        </View>
      </Camera>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  camera: {
    flex: 1,
    width: "100%",
    justifyContent: "flex-end", // Coloca os botões na parte inferior
    alignItems: "center",
  },
  buttonContainer: {
    backgroundColor: "transparent",
    flexDirection: "row",
    marginBottom: 20,
  },
});
