import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView, Image, Alert } from 'react-native';
import { Camera, CameraType } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';

export default function CameraScreen() {
  const [hasCameraPermission, setHasCameraPermission] = useState(null);
  const [hasMediaPermission, setHasMediaPermission] = useState(null);
  const [photo, setPhoto] = useState(null);
  const cameraRef = useRef(null);

  useEffect(() => {
    (async () => {
      // Pede permissão da câmera
      const cameraStatus = await Camera.requestCameraPermissionsAsync();
      setHasCameraPermission(cameraStatus.status === 'granted');

      // Pede permissão da galeria (Media Library)
      const mediaStatus = await MediaLibrary.requestPermissionsAsync();
      setHasMediaPermission(mediaStatus.status === 'granted');
    })();
  }, []);

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const newPhoto = await cameraRef.current.takePictureAsync({
          quality: 1,
        });
        setPhoto(newPhoto);
      } catch (e) {
        console.error("Erro ao tirar foto: ", e);
      }
    }
  };

  const savePicture = async () => {
    if (photo) {
      try {
        await MediaLibrary.saveToLibraryAsync(photo.uri);
        Alert.alert("Sucesso!", "Foto salva na galeria.");
        setPhoto(null); // Limpa a foto da tela
      } catch (e) {
        console.error("Erro ao salvar foto: ", e);
        Alert.alert("Erro", "Não foi possível salvar a foto.");
      }
    }
  };

  // Mensagens de permissão
  if (hasCameraPermission === null || hasMediaPermission === null) {
    return <View />;
  }
  if (hasCameraPermission === false) {
    return <Text style={styles.errorText}>Sem acesso à câmera. Por favor, habilite nas configurações.</Text>;
  }
  if (hasMediaPermission === false) {
    return <Text style={styles.errorText}>Sem acesso à galeria. Por favor, habilite nas configurações.</Text>;
  }

  // Se tem uma foto tirada, mostra a pré-visualização
  if (photo) {
    return (
      <SafeAreaView style={styles.container}>
        <Image source={{ uri: photo.uri }} style={styles.preview} />
        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.button} onPress={savePicture}>
            <Text style={styles.buttonText}>Salvar na Galeria</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => setPhoto(null)}>
            <Text style={styles.buttonText}>Tirar Outra</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Tela principal da câmera
  return (
    <SafeAreaView style={styles.container}>
      <Camera style={styles.camera} type={CameraType.back} ref={cameraRef} />
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.snapButton} onPress={takePicture}>
          <View style={styles.snapInnerButton} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
  },
  errorText: {
    flex: 1,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 16,
  },
  camera: {
    flex: 1,
    aspectRatio: 9 / 16, // Proporção de câmera de celular
  },
  buttonContainer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    padding: 30,
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  snapButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  snapInnerButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: '#000',
    backgroundColor: '#fff',
  },
  preview: {
    flex: 1,
    resizeMode: 'contain',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 20,
    backgroundColor: '#000',
  },
  button: {
    backgroundColor: '#3B82F6',
    padding: 15,
    borderRadius: 8,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});