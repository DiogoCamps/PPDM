import React, { useState } from "react";
import { View, Text, StyleSheet, Switch, Button } from "react-native";

export default function ConfigScreen() {
  const [isDarkMode, setIsDarkMode] = useState(false);  // Estado para controlar o tema
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(true);  // Estado para notificações

  // Funções para alternar os estados
  const toggleDarkMode = () => setIsDarkMode(previousState => !previousState);
  const toggleNotifications = () => setIsNotificationsEnabled(previousState => !previousState);

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? "#333" : "#fff" }]}>
      <Text style={[styles.title, { color: isDarkMode ? "#fff" : "#000" }]}>Tela de Configuração</Text>
      
      {/* Tema */}
      <View style={styles.optionContainer}>
        <Text style={[styles.text, { color: isDarkMode ? "#fff" : "#000" }]}>Modo Escuro</Text>
        <Switch
          value={isDarkMode}
          onValueChange={toggleDarkMode}
        />
      </View>

      {/* Notificações */}
      <View style={styles.optionContainer}>
        <Text style={[styles.text, { color: isDarkMode ? "#fff" : "#000" }]}>Notificações</Text>
        <Switch
          value={isNotificationsEnabled}
          onValueChange={toggleNotifications}
        />
      </View>

      {/* Botões de ação */}
      <Button 
        title="Salvar Configurações"
        onPress={() => alert('Configurações salvas!')}
      />
      <Button 
        title="Logout"
        color="red"
        onPress={() => alert('Você foi desconectado.')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 30,
  },
  text: {
    fontSize: 18,
    marginVertical: 10,
  },
  optionContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    marginVertical: 10,
  },
});