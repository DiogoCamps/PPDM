import React, { useState } from "react";
import { View, Text, StyleSheet, Switch, TouchableOpacity } from "react-native";
import { Ionicons } from '@expo/vector-icons';

export default function ConfigScreen() {
  // Estado para o Switch de Modo Escuro
  const [isDarkMode, setIsDarkMode] = useState(false);
  const toggleDarkMode = () => setIsDarkMode(previousState => !previousState);

  // Estado para o Switch de Notificações
  const [notificationsOn, setNotificationsOn] = useState(true);
  const toggleNotifications = () => setNotificationsOn(previousState => !previousState);

  return (
    // Um ScrollView seria bom se a lista crescesse, mas View é ok por agora
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Configurações</Text>

      {/* Seção de Preferências */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferências</Text>
        
        {/* Opção Modo Escuro */}
        <View style={styles.row}>
          <Ionicons name="moon-outline" size={24} color="#333" style={styles.icon} />
          <Text style={styles.rowLabel}>Modo Escuro</Text>
          <Switch
            trackColor={{ false: "#767577", true: "#447cecff" }}
            thumbColor={isDarkMode ? "#f4f3f4" : "#f4f3f4"}
            onValueChange={toggleDarkMode}
            value={isDarkMode}
          />
        </View>

        {/* Opção Notificações */}
        <View style={styles.row}>
          <Ionicons name="notifications-outline" size={24} color="#333" style={styles.icon} />
          <Text style={styles.rowLabel}>Notificações</Text>
          <Switch
            trackColor={{ false: "#767577", true: "#447cecff" }}
            thumbColor={notificationsOn ? "#f4f3f4" : "#f4f3f4"}
            onValueChange={toggleNotifications}
            value={notificationsOn}
          />
        </View>
      </View>

      {/* Seção de Informações */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Informações</Text>
        
        {/* Opção Sobre */}
        <TouchableOpacity style={styles.rowTouchable}>
          <Ionicons name="information-circle-outline" size={24} color="#333" style={styles.icon} />
          <Text style={styles.rowLabel}>Sobre o App</Text>
          <Ionicons name="chevron-forward-outline" size={24} color="#aaa" />
        </TouchableOpacity>

        {/* Opção Ajuda */}
        <TouchableOpacity style={styles.rowTouchable}>
          <Ionicons name="help-circle-outline" size={24} color="#333" style={styles.icon} />
          <Text style={styles.rowLabel}>Ajuda e Suporte</Text>
          <Ionicons name="chevron-forward-outline" size={24} color="#aaa" />
        </TouchableOpacity>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f2f7', // Fundo de configurações padrão iOS
  },
  headerTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  section: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: 'white',
    borderRadius: 10,
    overflow: 'hidden', // Garante que as bordas fiquem arredondadas
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
    paddingTop: 15,
    paddingBottom: 5,
    paddingHorizontal: 15,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f2f2f7',
  },
  rowTouchable: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f2f2f7',
  },
  icon: {
    marginRight: 15,
    width: 25, // Alinha os textos
  },
  rowLabel: {
    flex: 1, // Faz a label empurrar o Switch para a direita
    fontSize: 17,
    color: '#111',
  },
  // (Estilos title e text originais não usados)
  title: {
    fontSize: 24,
    marginBottom: 10,
  },
  text: {
    color: "#447cecff",
    fontSize: 24,
  },
});