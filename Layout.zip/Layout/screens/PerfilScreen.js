import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
// Importa ícones
import { Ionicons } from '@expo/vector-icons';

export default function PerfilScreen() {
  return (
    <View style={styles.container}>
      {/* Ícone do Avatar */}
      <Ionicons name="person-circle-outline" size={150} color="#447cecff" />

      {/* Nome do Usuário */}
      <Text style={styles.title}>Diogo Campos</Text>
      
      {/* Email do Usuário */}
      <Text style={styles.email}>usuario@gmail.com</Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: '#f9f9f9', // Um fundo levemente cinza
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  email: {
    fontSize: 16,
    color: '#666',
    marginBottom: 24,
  },
  // Estilo do botão
  button: {
    flexDirection: 'row',
    backgroundColor: '#447cecff',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    // Sombra
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8, // Espaço entre o ícone e o texto
  },
  // (Estilo 'text' original não usado)
  text: {
    color: "#447cecff",
    fontSize: 24,
  },
});