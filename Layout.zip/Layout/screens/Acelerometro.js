import React, { useState, useEffect } from "react";
import { Text, View, StyleSheet } from "react-native";
import { Accelerometer } from "expo-sensors";
import * as Device from "expo-device";

export default function Acelerometro() {
  const [data, setData] = useState({ x: 0, y: 0, z: 0 });
  const [isMobile, setIsMobile] = useState(Device.isDevice); // Detecta direto
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!isMobile) return; // Se não for dispositivo físico, não tenta ler sensor

    let subscription;

    try {
      subscription = Accelerometer.addListener((accelerometerData) => {
        setData(accelerometerData);
      });

      Accelerometer.setUpdateInterval(100); // Atualiza a cada 100ms
    } catch (e) {
      setError("Erro ao acessar o acelerômetro.");
    }

    return () => {
      subscription && subscription.remove();
    };
  }, [isMobile]);

  const { x, y, z } = data;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Acelerômetro</Text>

      {error && <Text style={styles.text}>{error}</Text>}

      {isMobile ? (
        <>
          <Text style={styles.text}>x: {x.toFixed(2)}</Text>
          <Text style={styles.text}>y: {y.toFixed(2)}</Text>
          <Text style={styles.text}>z: {z.toFixed(2)}</Text>
        </>
      ) : (
        <Text style={styles.text}>Acelerômetro não disponível na web.</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  header: {
    fontSize: 30,
    marginBottom: 20,
  },
  text: {
    fontSize: 20,
  },
});
