import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  FlatList,
  ActivityIndicator,
  Alert
} from 'react-native';
// 1. Importar o AsyncStorage que você instalou
import AsyncStorage from '@react-native-async-storage/async-storage';

// Chave onde salvaremos nossa lista no armazenamento
const STORAGE_KEY = '@cadastro_de_itens';

// 2. Mude o nome do componente para 'LocalStorage' para bater com seu App.js
export default function LocalStorage() {
  const [itens, setItens] = useState([]);
  const [novoItem, setNovoItem] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // 1. Carregar dados salvos ao iniciar o componente
  useEffect(() => {
    async function carregarDados() {
      try {
        // Usar AsyncStorage.getItem
        const dadosSalvos = await AsyncStorage.getItem(STORAGE_KEY);
        
        if (dadosSalvos !== null) {
          setItens(JSON.parse(dadosSalvos));
        }
      } catch (e) {
        console.error("Falha ao carregar os dados.", e);
        Alert.alert("Erro", "Falha ao carregar os dados.");
      }
      setIsLoading(false);
    }

    carregarDados();
  }, []); // O array vazio [] garante que isso rode apenas uma vez

  // 2. Salvar dados sempre que a lista de 'itens' mudar
  const salvarDados = async (novosItens) => {
    try {
      const dadosString = JSON.stringify(novosItens);
      // Usar AsyncStorage.setItem
      await AsyncStorage.setItem(STORAGE_KEY, dadosString);
    } catch (e) {
      console.error("Falha ao salvar os dados.", e);
      Alert.alert("Erro", "Falha ao salvar os dados.");
    }
  };

  // 3. Adicionar um novo item
  const handleAddItem = () => {
    if (novoItem.trim() === '') return; // Ignora se estiver vazio
    
    const novaLista = [...itens, novoItem];
    setItens(novaLista);
    salvarDados(novaLista); // Salva a nova lista
    setNovoItem(''); // Limpa o campo de texto
  };

  // 4. Remover um item
  const handleRemoveItem = (indexParaRemover) => {
    const novaLista = itens.filter((_, index) => index !== indexParaRemover);
    setItens(novaLista);
    salvarDados(novaLista); // Salva a nova lista
  };

  // Enquanto carrega, mostra uma mensagem
  if (isLoading) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.bodyText}>Carregando dados...</Text>
      </SafeAreaView>
    );
  }

  // --- JSX (Renderização NATIVA) ---
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Cadastro de Itens</Text>
        <Text style={styles.bodyText}>
          (Estes itens são salvos no dispositivo)
        </Text>

        {/* Input e Botão de Adicionar */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Digite um novo item..."
            placeholderTextColor="#9ca3af"
            value={novoItem}
            onChangeText={setNovoItem} // Usar onChangeText
          />
          <TouchableOpacity style={styles.button} onPress={handleAddItem}>
            <Text style={styles.buttonText}>Adicionar</Text>
          </TouchableOpacity>
        </View>

        {/* Usar <FlatList> para listas */}
        <FlatList
          style={styles.listContainer}
          data={itens}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => (
            <View style={styles.itemRow}>
              <Text style={styles.itemText}>{item}</Text>
              <TouchableOpacity 
                style={styles.deleteButton}
                onPress={() => handleRemoveItem(index)}
              >
                <Text style={styles.deleteButtonText}>X</Text>
              </TouchableOpacity>
            </View>
          )}
          ListEmptyComponent={() => (
            <Text style={styles.itemText}>Nenhum item cadastrado.</Text>
          )}
        />
      </View>
    </SafeAreaView>
  );
}

// --- Usar StyleSheet.create ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    padding: 20,
    justifyContent: 'flex-start', // Alinha no topo
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 24,
    width: '100%',
    // Shadow para iOS
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    // Shadow para Android
    elevation: 5,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
    color: '#111827',
  },
  bodyText: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row', // Em vez de 'display: flex'
    marginBottom: 20,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#d1d5db',
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    color: '#111827',
  },
  button: {
    backgroundColor: '#3B82F6',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  listContainer: {
    borderTopWidth: 1,
    borderColor: '#e5e7eb',
    paddingTop: 12,
    maxHeight: 300, // Adiciona um limite de altura para a lista
  },
  itemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  itemText: {
    fontSize: 16,
    color: '#111827',
    flex: 1, // Permite que o texto quebre a linha se for longo
  },
  deleteButton: {
    backgroundColor: '#EF4444',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginLeft: 10, // Espaço entre o texto e o botão
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
  }
});