import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator
} from 'react-native';
// 1. Importar o expo-network que você instalou
import * as Network from 'expo-network';

export default function WifiScreen() {
  const [networkState, setNetworkState] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Efeito para carregar os dados ao iniciar
  useEffect(() => {
    checkConnection();
  }, []);

  // Função para verificar o tipo de conexão
  const checkConnection = async () => {
    setIsLoading(true);
    setNetworkState(null); // Limpa o estado anterior
    
    // --- Lógica NATIVA do Expo ---
    try {
      // Obtém o estado da rede
      const state = await Network.getNetworkStateAsync();
      setNetworkState(state);

    } catch (e) {
      console.error("Erro ao verificar rede", e);
      Alert.alert("Erro", "Não foi possível verificar a rede.");
    }
    setIsLoading(false);
  };

  // Função auxiliar para formatar o tipo de conexão
  const getConnectionTypeString = () => {
    if (!networkState || !networkState.type) {
      return 'Desconhecido';
    }
    // Converte de 'Network.NetworkStateType.WIFI' para 'WIFI'
    // O 'expo-network' retorna um enum, vamos pegar o nome
    const typeKey = Object.keys(Network.NetworkStateType).find(
      key => Network.NetworkStateType[key] === networkState.type
    );
    return typeKey || 'Desconhecido';
  };

  const isOnline = networkState?.isConnected;
  const connectionType = getConnectionTypeString();

  return (
    // 2. Usar componentes NATIVOS
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Status da Rede (Expo)</Text>
        
        {/* Mostra o spinner enquanto carrega */}
        {isLoading && <ActivityIndicator size="large" color="#3B82F6" style={styles.loader} />}

        {/* Mostra os resultados depois de carregar */}
        {!isLoading && networkState && (
          <>
            <View style={styles.statusBox}>
              <Text style={styles.statusLabel}>Status:</Text>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text 
                  style={[styles.statusValue, { color: isOnline ? '#10B981' : '#EF4444' }]}
                >
                  {isOnline ? 'ONLINE' : 'OFFLINE'}
                </Text>
                <View style={[styles.dot, { backgroundColor: isOnline ? '#10B981' : '#EF4444' }]} />
              </View>
            </View>

            <View style={styles.statusBox}>
              <Text style={styles.statusLabel}>Tipo de Conexão:</Text>
              <Text style={styles.statusValue}>
                {connectionType}
              </Text>
            </View>
            
            <View style={styles.statusBox}>
              <Text style={styles.statusLabel}>Internet Acessível:</Text>
              <Text style={styles.statusValue}>
                {networkState.isInternetReachable ? 'Sim' : 'Não'}
              </Text>
            </View>
          </>
        )}
        
        <TouchableOpacity 
          style={styles.button} 
          onPress={checkConnection}
          disabled={isLoading}
        >
          <Text style={styles.buttonText}>
            {isLoading ? 'Verificando...' : 'Verificar Novamente'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// 3. Usar StyleSheet.create
const styles = StyleSheet.create({
  container: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f3f4f6',
    padding: 20,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
    color: '#111827',
  },
  loader: {
    marginVertical: 20,
  },
  statusBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  statusLabel: {
    fontSize: 16,
    color: '#374151', // Cinza escuro
  },
  statusValue: {
    fontSize: 16,
    fontWeight: '600',
  },
  dot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginLeft: 8,
  },
  button: {
    backgroundColor: '#3B82F6',
    padding: 12, // Um pouco menor que o anterior
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
    marginTop: 24,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  }
});