import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import Header from "../src/components/Header";
import Footer from "../src/components/Footer";

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Header />
      <View style={styles.profileContainer}>
        <Text style={styles.text}>Seja bem-vindo!</Text>
        <Text style={styles.texts}>Abra o menu lateral</Text>
        <Image
                  source={require('../assets/tela.gif')}
                  style={styles.profileImage}
                />
      </View>
      <Footer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start", // Alterado para que o conteúdo ocupe o espaço restante
  },
  profileContainer: {
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 8,
    elevation: 4, // Para Android
    flex: 1, // Permite que o conteúdo central ocupe o restante do espaço disponível
  },
  profileImage: {
    width: 300,
    height: 200,
    borderRadius: 10,
    marginBottom: 15,
  },
  title: {
    fontSize: 24,
    marginBottom: 10,
  },
  text: {
    color: "white",
    fontSize: 24,
    textShadowColor: "black",
    textShadowOffset: { width: 2, height: 2 }, 
    textShadowRadius: 3,
  },
  texts: {
    color: "red",
    fontSize: 24,
  },
});
