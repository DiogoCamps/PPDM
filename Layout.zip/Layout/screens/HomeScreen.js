import React from "react";
import { View, Text, StyleSheet } from "react-native";
// Importa ícones do Expo
import { Ionicons } from '@expo/vector-icons'; 

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      {}
      <Ionicons name="apps-sharp" size={60} color="#447cecff" />

      {/* Título atualizado */}
      <Text style={styles.title}>Bem-vindo a Home do App PPDM!</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20, // Adiciona padding
  },
  title: {
    fontSize: 26, // Aumenta o título
    fontWeight: 'bold', // Deixa em negrito
    marginTop: 20,
    marginBottom: 10,
    textAlign: 'center',
  },
  text: {
    color: "#444", // Cor mais escura para ler melhor
    fontSize: 16, // Tamanho de fonte legível
    textAlign: 'center',
    marginBottom: 5,
  },
  list: {
    marginTop: 20,
    alignSelf: 'stretch', // Estica o container
    paddingHorizontal: 20,
  },
  listItem: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
  }
});