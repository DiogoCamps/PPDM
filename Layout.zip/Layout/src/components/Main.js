import React from "react";
import { View, Text, StyleSheet, Button, Image } from "react-native";

export default function Main() {
  return (
    <View style={styles.main}>
      <Text style={styles.title}>Bem-Vindo</Text>
      <Image
        source={{ uri: "https://reactnative.dev/img/tiny_logo.png" }}
        style={styles.image}
      />
      <Text style={styles.description}>
        Este é um exemplo de layout utilizando Expo Native
      </Text>
      <Button title="Clique Aqui" onPress={() => alert("Botão pressionado")} />
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    padding: 20,
    backgroundColor: "#6a08f2ff",
    alignItems: "center",
  },
  title: {
    color: "#eceff5ff",
    fontSize: 24,
    marginBottom: 15,
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 15,
  },
  description: {
    color: "#eceff5ff",
    fontSize: 24,
    textAlign: "center",
    marginBottom: 15,
  },
});
